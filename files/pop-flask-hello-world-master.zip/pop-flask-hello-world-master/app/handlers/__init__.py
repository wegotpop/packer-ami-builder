from app.handlers import index
from app.handlers import healthcheck
from app.handlers import api