from flask import render_template

def _say_hello(username = "World"):
    return '<p>Hello %s!</p>\n' % username

def index():
	return render_template('index.html', username="World", show_hint=True)

def hello(username):
	return render_template('index.html', username=username, show_hint=False, show_back=True)