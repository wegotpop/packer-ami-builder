from flask import Flask

import app.handlers as handlers


# EB looks for an 'application' callable by default.
application = Flask(__name__)

# Healthcheck
application.add_url_rule('/healthcheck', 'healthcheck', handlers.healthcheck.check)


# HTML Demo
application.add_url_rule('/', 'index', handlers.index.index)
application.add_url_rule('/<username>', 'hello', handlers.index.hello)

# API example
application.add_url_rule('/api/hello', 'api-hello', handlers.api.hello)

# run the app.
if __name__ == "__main__":
    # Setting debug to True enables debug output. This line should be
    # removed before deploying a production app.
    application.debug = True
    application.run()
